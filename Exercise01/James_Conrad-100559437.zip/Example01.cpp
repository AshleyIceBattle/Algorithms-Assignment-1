// Core Libraries
#include <iostream>
#include <string>
#include <math.h>

// 3rd Party Libraries
#include <GLUT\glut.h>

// Defines and Core variables
#define FRAMES_PER_SECOND 60
const int FRAME_DELAY = 1000 / FRAMES_PER_SECOND; // Miliseconds per frame

int windowWidth = 800;
int windowHeight = 600;

int mousepositionX;
int mousepositionY;

// A few conversions to know
float degToRad = 3.14159f / 180.0f;
float radToDeg = 180.0f / 3.14159f;

float rotx, roty;

/* function DisplayCallbackFunction(void)
* Description:
*  - this is the openGL display routine
*  - this draws the sprites appropriately
*/
void DisplayCallbackFunction(void)
{
	/* clear the screen */
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity(); // clear our the transform matrix

	/* This is where we draw thigns */


	//Transformations

	glTranslatef(0.f, 0.f, -200.f);
	glRotatef(rotx, 0.f, 1.f, 0.f);
	glRotatef(roty, 1.f, 0.f, 0.f);
	//glRotatef(rotz, 0.f, 0.f, 0.f);

	glBegin(GL_QUADS);
	glColor3f(0.0f, 0.8f, 0.0f);
	glVertex3f(-50.0f, -50.0f, -50.0f);
	  glColor4f(1.0f, 0.0f, 0.0f, 1.0f);
	glVertex3f(-50.0f, 50.0f, -50.0f);
	  glColor4f(0.0f, 1.0f, 0.0f, 1.0f);
	glVertex3f(50.0f, 50.0f, -50.0f);
	  glColor4f(0.0f, 0.0f, 1.0f, 1.0f);
	glVertex3f(50.0f, -50.0f, -50.0f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3f(0.8f, 0.0f, 0.0f);
	glVertex3f(-50.0f, -50.0f, 50.0f);
	  glColor4f(1.0f, 0.0f, 0.0f, 1.0f);
	glVertex3f(-50.0f, 50.0f, 50.0f);
	  glColor4f(0.0f, 1.0f, 0.0f, 1.0f);
	glVertex3f(50.0f, 50.0f, 50.0f);
	  glColor4f(0.0f, 0.0f, 1.0f, 1.0f);
	glVertex3f(50.0f, -50.0f, 50.0f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3f(0.0f, 0.f, 0.8f);
	glVertex3f(-50.0f, 50.0f, -50.0f);
	  glColor4f(1.0f, 0.0f, 0.0f, 1.0f);
	glVertex3f(-50.0f, 50.0f, 50.0f);
	  glColor4f(0.0f, 1.0f, 0.0f, 1.0f);
	glVertex3f(50.0f, 50.0f, 50.0f);
	  glColor4f(0.0f, 0.0f, 1.0f, 1.0f);
	glVertex3f(50.0f, 50.0f, -50.0f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3f(0.8f, 0.8f, 0.0f);
	glVertex3f(-50.0f, -50.0f, -50.0f);
	  glColor4f(1.0f, 0.0f, 0.0f, 1.0f);
	glVertex3f(-50.0f, -50.0f, 50.0f);
	  glColor4f(0.0f, 1.0f, 0.0f, 1.0f);
	glVertex3f(50.0f, -50.0f, 50.0f);
	  glColor4f(0.0f, 0.0f, 1.0f, 1.0f);
	glVertex3f(50.0f, -50.0f, -50.0f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3f(0.8f, 0.0f, 0.8f);
	glVertex3f(50.0f, -50.0f, -50.0f);
	  glColor4f(1.0f, 0.0f, 0.0f, 1.0f);
	glVertex3f(50.0f, 50.0f, -50.0f);
	  glColor4f(0.0f, 1.0f, 0.0f, 1.0f);
	glVertex3f(50.0f, 50.0f, 50.0f);
	  glColor4f(0.0f, 0.0f, 1.0f, 1.0f);
	glVertex3f(50.0f, -50.0f, 50.0f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3f(0.0f, 0.8f, 0.8f);
	glVertex3f(-50.0f, -50.0f, -50.0f);
	  glColor4f(1.0f, 0.0f, 0.0f, 1.0f);
	glVertex3f(-50.0f, 50.0f, -50.0f);
	  glColor4f(0.0f, 1.0f, 0.0f, 1.0f);
	glVertex3f(-50.0f, 50.0f, 50.0f);
	  glColor4f(0.0f, 0.0f, 1.0f, 1.0f);
	glVertex3f(-50.0f, -50.0f, 50.0f);
	glEnd();

	/* Swap Buffers to Make it show up on screen */
	glutSwapBuffers();
}

/* function void KeyboardCallbackFunction(unsigned char, int,int)
* Description:
*   - this handles keyboard input when a button is pressed
*/
void KeyboardCallbackFunction(unsigned char key, int x, int y)
{
	std::cout << "Key Down:" << (int)key << std::endl;
	
	switch (key)
	{
		case 32: // the space bar
			break;
		case 'a':
			rotx += 1.0f;
			break;
		case 'd':
			rotx -= 1.0f;
			break;
		case 'w':
			roty += 1.0f;
			break;
		case 's':
			roty -= 1.0f;
			break;
		case 27: // the escape key
		case 'q': // the 'q' key
			exit(0);
			break;
	}
}

/* function void KeyboardUpCallbackFunction(unsigned char, int,int)
* Description:
*   - this handles keyboard input when a button is lifted
*/
void KeyboardUpCallbackFunction(unsigned char key, int x, int y)
{
}

void idleFunc()
{

}

/* function TimerCallbackFunction(int value)
* Description:
*  - this is called many times per second
*  - this enables you to animate things
*  - no drawing, just changing the state
*  - changes the frame number and calls for a redisplay
*  - FRAME_DELAY is the number of milliseconds to wait before calling the timer again
*/
void TimerCallbackFunction(int value)
{
	/* this call makes it actually show up on screen */
	glutPostRedisplay();

	/* this call gives it a proper frame delay to hit our target FPS */
	glutTimerFunc(FRAME_DELAY, TimerCallbackFunction, 0);
}

/* function WindowReshapeCallbackFunction()
* Description:
*  - this is called whenever the window is resized
*  - and sets up the projection matrix properly
*/
void WindowReshapeCallbackFunction(int w, int h)
{
	// switch to projection because we're changing projection
	float asp = (float)w / (float)h;
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	// Setup a perspective projection
	gluPerspective(90.f, asp, 1.f, 500.f); // (fov, aspect, near z, far z)	

	//gluOrtho2D(0, w, 0, h);

	windowWidth = w;
	windowHeight = h;
	glViewport(0, 0, windowWidth, windowHeight);

	//switch back to modelview
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void MouseClickCallbackFunction(int button, int state, int x, int y)
{
	// Handle mouse clicks
	if (state == GLUT_DOWN)
	{
		std::cout << "Mouse x:" << x << " y:" << y << std::endl;
	}
}


/* function MouseMotionCallbackFunction()
* Description:
*   - this is called when the mouse is clicked and moves
*/
void MouseMotionCallbackFunction(int x, int y)
{
}

/* function MousePassiveMotionCallbackFunction()
* Description:
*   - this is called when the mouse is moved in the window
*/
void MousePassiveMotionCallbackFunction(int x, int y)
{
	mousepositionX = x;
	mousepositionY = y;
}

void init()
{
	///// INIT OpenGL /////
	// Set color clear value
	glClearColor(0.2f, 0.2f, 0.2f, 1.f);

	// Enable Z-buffer read and write (for hidden surface removal)
	glEnable(GL_DEPTH_TEST);

	glEnable(GL_TEXTURE_2D); // textures for future use

}


/* function main()
* Description:
*  - this is the main function
*  - does initialization and then calls glutMainLoop() to start the event handler
*/

int main(int argc, char **argv)
{
	/* initialize the window and OpenGL properly */
	glutInit(&argc, argv);
	glutInitWindowSize(windowWidth, windowHeight);
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE);
	glutCreateWindow("INFR1350U - Example");

	/* set up our function callbacks */
	glutDisplayFunc(DisplayCallbackFunction);
	glutKeyboardFunc(KeyboardCallbackFunction);
	glutKeyboardUpFunc(KeyboardUpCallbackFunction);
	glutIdleFunc(idleFunc);
	glutReshapeFunc(WindowReshapeCallbackFunction);
	glutMouseFunc(MouseClickCallbackFunction);
	glutMotionFunc(MouseMotionCallbackFunction);
	glutPassiveMotionFunc(MousePassiveMotionCallbackFunction);
	glutTimerFunc(1, TimerCallbackFunction, 0);

	init(); //Setup OpenGL States

	/* start the event handler */
	glutMainLoop();
	return 0;
}